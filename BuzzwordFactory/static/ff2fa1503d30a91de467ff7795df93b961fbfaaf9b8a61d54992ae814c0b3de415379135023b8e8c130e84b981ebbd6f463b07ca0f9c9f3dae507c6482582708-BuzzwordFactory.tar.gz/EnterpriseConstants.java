public class EnterpriseConstants {
    public static final int WELCOME = 0;
    public static final int OPTIONS = 1;
}
